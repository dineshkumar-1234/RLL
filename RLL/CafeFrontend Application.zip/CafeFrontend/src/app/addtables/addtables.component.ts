
// ankithas
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Tables } from '../tablemodel';

@Component({
  selector: 'app-addtables',
  templateUrl: './addtables.component.html',
  styleUrls: ['./addtables.component.css']
})
export class AddtablesComponent {
  table: Tables = new Tables();
  submitted = false;
  showError = false;

  constructor(private router: Router, private adminService: AdminService) { }

  onTableSubmit() {
    // Validate the form before submitting
    if (this.isValidForm()) {
      this.adminService.addTables(this.table).subscribe(
        data => {
          this.table=new Tables();
          this.submitted = true;
          this.showError = false; // Reset error flag
        },
        error => {
          console.error('Error adding tables:', error);
          // Optionally handle error and provide error message to the user
        }
        
      );
    } else {
      this.showError = true;
    }
  }

  // Form validation logic
  isValidForm(): boolean {
    return (
      !!this.table.tablerow &&
      !!this.table.tablenumber &&
      !!this.table.tablecapacity &&
      !!this.table.tabletype
    );
  }

  gotoAddTables() {
    this.router.navigate(['/addtables']);
  }
}


//   ngOnInit(): void {
//     this. gotoAddTables();
//   }
//   onTablesSubmit(){
//   this.adminService.addTables(this.table).subscribe(
//     data=>{
//       this.table=new Tables();
//     }
//   );
  
//   }
//   onTableSubmit(){
// this.onTablesSubmit();
// this.gotoAddTables();
// this.submitted=true;
//   }





// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { AdminService } from '../admin.service';
// import { Tables } from '../tablemodel';
 
// @Component({
//   selector: 'app-addtables',
//   templateUrl: './addtables.component.html',
//   styleUrls: ['./addtables.component.css']
// })
// export class AddtablesComponent implements OnInit {
//   table:Tables=new Tables();
//   submitted=false;
//   constructor(private router:Router,private adminService:AdminService)  { }
 
//   ngOnInit(): void {
//     this. gotoAddTables();
//   }
//   onTablesSubmit(){
//   this.adminService.addTables(this.table).subscribe(
//     data=>{
//       this.table=new Tables();
//     }
//   );
 
//   }
//   onTableSubmit(){
// this.onTablesSubmit();
// this.gotoAddTables();
// this.submitted=true;
//   }
 
 
//   gotoAddTables(){
//     this.router.navigate(['/addtables']);
//     }
// }
 