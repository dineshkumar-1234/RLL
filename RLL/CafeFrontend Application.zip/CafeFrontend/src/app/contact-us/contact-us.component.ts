import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {

}
document.addEventListener('DOMContentLoaded', function () {
  const contactForm = document.getElementById('contactForm') as HTMLFormElement;
  const successMessage = document.getElementById('successMessage');

  if (contactForm && successMessage) {
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();

      // Add form validation logic here
      const firstNameInput = contactForm.querySelector('.fname') as HTMLInputElement;
      const lastNameInput = contactForm.querySelector('.lname') as HTMLInputElement;
      const emailInput = contactForm.querySelector('.email') as HTMLInputElement;
      const phoneInput = contactForm.querySelector('.phone') as HTMLInputElement;
      const messageTextarea = contactForm.querySelector('textarea') as HTMLTextAreaElement;

      if (
        firstNameInput.value.trim() === '' ||
        lastNameInput.value.trim() === '' ||
        emailInput.value.trim() === '' ||
        phoneInput.value.trim() === '' ||
        messageTextarea.value.trim() === ''
      ) {
        // Show an error message or handle invalid form data as needed
        alert('Please fill in all fields');
        return;
      }

      // Add any additional form processing logic here

      // For demonstration purposes, show the success message and reset the form
      showSuccessMessage(successMessage, contactForm);
    });
  }
});

function showSuccessMessage(successMessage: HTMLElement, form: HTMLFormElement) {
  // Display the success message
  successMessage.style.color = 'green'; // Set the color if needed
  successMessage.style.marginTop = '10pt';
  successMessage.style.display = 'block';

  // Reset the form after a delay (you can adjust the delay as needed)
  setTimeout(function () {
    successMessage.style.display = 'none';
    form.reset();
  }, 3000); // 3000 milliseconds (3 seconds) delay for demonstration
}
